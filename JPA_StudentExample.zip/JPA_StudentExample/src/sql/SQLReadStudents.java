package sql;

import java.sql.DriverManager;
import java.sql.ResultSet;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class SQLReadStudents {

    final static String name = "artur";
    final static String password = "fonseca";

    public static void main(String[] args) {
        try {
            String url = "jdbc:mysql://localhost:3306/StudentDB";
            Connection conn = (Connection) DriverManager.getConnection(url, name, password);
            Statement stmt = (Statement) conn.createStatement();
            ResultSet rs;

            rs = stmt.executeQuery("SELECT * FROM STUDENTS_TABLE");
            while (rs.next()) {
                Long id = rs.getLong("studentid");
                String nme = rs.getString("Name");
                String phone = rs.getString("Phone");
                System.out.println(id + ": " + nme + " " + phone);
            }
            conn.close();
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
    }
}
