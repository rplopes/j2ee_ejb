package common;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GetStudentInfo {
	static List<Student> list;

	public static List<Student> get() {
		list = new ArrayList<Student>();
		boolean done = false;
		Scanner sc = new Scanner(System.in);
		while (!done) {
			System.out.println("Student's name (empty to finish): ");
			String name = sc.nextLine();
			done = name.equals("");
			if (!done) {
				System.out.println("Student's phone: ");
				String phone = sc.nextLine();
				list.add(new Student(name, phone));
			}
		}
		return list;
	}
}