/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jpa;

import common.Student;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author filipius
 */
public class JPAReadStudents {
    public static void main(String args[]) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("TestPersistence");
        EntityManager em = emf.createEntityManager();
        //EntityTransaction tx = em.getTransaction();

        String query = "SELECT s FROM Student s";
        List<Student> mylist = (List<Student>) em.createQuery(query).getResultList();
        for (Student st : mylist)
            System.out.println(st);
    }
}
