package ejbs;
import javax.ejb.Remote;

@Remote
public interface SqrRoot {
	public double compute(double num); 
    public double resultById(int num);
}
