package ejbs;


import java.util.List;

import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import data.Result;

/**
 * Session Bean implementation class SqrRootBean
 */
@Stateful
public class SqrRootBean implements SqrRoot {

	@PersistenceContext(unitName="TestPersistence")
	private EntityManager em;
	
    /**
     * Default constructor. 
     */
    public SqrRootBean() {
    }

    public double compute(double num) {
    	double res;
    	
		String query = "SELECT r FROM Result r WHERE r.num = " + num;
		
		@SuppressWarnings("unchecked")
		List<Result> qresult = (List<Result>) em.createQuery(query).getResultList();

		if (qresult.size() > 0)
			res = qresult.get(0).getResult();
		else {
			res = Math.sqrt(num);
			em.persist(new Result(num, res));
		}
    	return res;
    }
    
    public double resultById(int num) {
    	Result r = em.find(Result.class, num);
    	return r.getResult();
    }

}
