import java.util.Scanner;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import ejbs.SqrRoot;


public class UseSqrt {

	/**
	 * @param args
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws NamingException {
		InitialContext ctx = new InitialContext();
		SqrRoot sqroot = (SqrRoot) ctx.lookup("SqrRootBean/remote");
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Pick a number: ");
		double num = sc.nextDouble();

		System.out.println("Square root of " + num + " = " + sqroot.compute(num));
		
		System.out.println("Result 1: " + sqroot.resultById(1));
	}

}
